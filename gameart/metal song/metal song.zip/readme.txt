License: CC0
Author: The Real Monoton Artist (http://www.soundcloud.com/the-real-monoton-artist)

created for Global Game Jam 2015
all art created for the game: http://opengameart.org/content/cute-cartoony-game
