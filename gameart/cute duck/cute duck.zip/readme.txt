License: CC0
Author: Rick Hoppmann, game developer & photographer (www.tinyworlds.org)

created for Global Game Jam 2015
all art created for the game: http://opengameart.org/content/cute-cartoony-game
