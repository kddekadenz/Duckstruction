License: CC0
Author: Rebekka Helzle (http://onmywaytogamedesign.wordpress.com/)

created for Global Game Jam 2015
all art created for the game: http://opengameart.org/content/cute-cartoony-game
